#ifndef PWM_H
#define PWM_H
#include "stm32f10x.h"
void PWMconfig(void);
void PWM_PULSEWITH(float CC_compare);
#endif
