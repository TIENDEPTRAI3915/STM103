#ifndef MAIN_H
#define MAIN_H
#include "stm32f10x.h"
#include "GPIO.h"
#include "UART.h"
#include "delay.h"
#include "ENCODER.h"
#include "PWM.h"
#endif
