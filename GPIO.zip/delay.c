#include "delay.h"

void delayinit(void)
{ RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1,ENABLE);

	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStucture;
	TIM_TimeBaseInitStucture.TIM_ClockDivision=TIM_CKD_DIV1;
	TIM_TimeBaseInitStucture.TIM_CounterMode=TIM_CounterMode_Up ;
	TIM_TimeBaseInitStucture.TIM_Period=0xffff;
	TIM_TimeBaseInitStucture.TIM_Prescaler=71;
	TIM_TimeBaseInitStucture.TIM_RepetitionCounter=0;
	
   TIM_TimeBaseInit(TIM1,&TIM_TimeBaseInitStucture);
	TIM_Cmd(TIM1,ENABLE);
}
void delayms(uint16_t timems)
{
	while(timems--)
		{	TIM1->CNT=0;
			while(TIM1->CNT<1000)
			;
		}
}
void delayus(uint16_t timeus)
{
			TIM1->CNT=0;
			while(TIM1->CNT<timeus)
			;

}
