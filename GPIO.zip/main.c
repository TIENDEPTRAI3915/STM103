#include "stm32f10x.h"
#include "GPIO.h"
#include "UART.h"
#include "delay.h"
#include "I2C.h"
#include "string.h"
#include "encode.h"
#include "ADC.h"

extern volatile char USART_DATA[5];
volatile char TXfame[5]={'*',0,0,0,0,0};
volatile char temp;
extern uint16_t ADC_data;
float LM35_TEMP=0;
float LM32_MEANTEMP=0;
uint8_t LM35_Hbyte=0;
uint8_t LM35_Lbyte=0;
void DMA1_Channel5_IRQHandler(void)
{
	if(DMA_GetITStatus(DMA1_IT_TC5)==ENABLE)
	{
		if( USART_DATA[0]!='*' || USART_DATA[4]!='*'||((USART_DATA[1]+USART_DATA[2])&0xff)!=USART_DATA[3] )
		{
				TXfame[1]='E';
				TXfame[2]=USART_DATA[1];
				TXfame[3]=USART_DATA[2];
				TXfame[4]='*';
				guichu(TXfame);
		}
		else
		{
				switch (USART_DATA[1]){
					case 'A':
								switch (USART_DATA[2]){
									case 'O':GPIO_ResetBits(GPIOC,GPIO_Pin_13);
													temp=(GPIOC->ODR>>13)&0x01;
													switch (temp){
														case 0:
															TXfame[1]='A';
															TXfame[2]='O';
															TXfame[3]='*';
															TXfame[4]=0;
															break;															
														case 1:
															TXfame[1]='A';
															TXfame[2]=0xFE;
															TXfame[3]='*';
															TXfame[4]=0;																												
															break;
													}
									break;
									case 'C':GPIO_SetBits(GPIOC,GPIO_Pin_13);
													temp=(GPIOC->ODR>>13)&0x01;
													switch (temp){
														case 0:
															TXfame[1]='A';
															TXfame[2]=0xFD;
															TXfame[3]='*';
															TXfame[4]=0;															
															break;
														case 1:
															TXfame[1]='A';
															TXfame[2]='C';
															TXfame[3]='*';
															TXfame[4]=0;															
															break;
													}
									break;
									default:
										TXfame[1]='A';
										TXfame[2]=0xFF;
										TXfame[3]='*';
										TXfame[4]=0;
								}
									guichu(TXfame);
					break;
					case 'B':
								switch (USART_DATA[2]){
									case 'O':GPIO_ResetBits(GPIOC,GPIO_Pin_14);
													temp=(GPIOC->ODR>>14)&0x01;
													switch (temp){
														case 0:
															TXfame[1]='B';
															TXfame[2]='O';
															TXfame[3]='*';
															TXfame[4]=0;														
															break;
														case 1:
															TXfame[1]='B';
															TXfame[2]=0xFE;
															TXfame[3]='*';
															TXfame[4]=0;	
															break;
													}
									break;
									case 'C':GPIO_SetBits(GPIOC,GPIO_Pin_14);
													temp=(GPIOC->ODR>>14)&0x01;
													switch (temp){
														case 0:
															TXfame[1]='B';
															TXfame[2]=0xFD;
															TXfame[3]='*';
															TXfame[4]=0;															
															break;
														case 1:
															TXfame[1]='B';
															TXfame[2]='C';
															TXfame[3]='*';
															TXfame[4]=0;															
															break;
													}
									break;
									default:
										TXfame[1]='B';
										TXfame[2]=0xFF;
										TXfame[3]='*';
										TXfame[4]=0;
								}
									guichu(TXfame);
					break;
					case 'T':
								switch (USART_DATA[2]){
									case 'G'://ADC
										TXfame[1]='T';
										TXfame[2]=LM32_MEANTEMP/1;
										TXfame[3]=LM32_MEANTEMP*100-TXfame[2]*100;
										TXfame[4]='*';
										guichu(TXfame);
										break;
									default:
										TXfame[1]='T';
										TXfame[2]=0xFF;
										TXfame[3]=0xFF;
										TXfame[4]='*';
										guichu(TXfame);							
								}									
					break;
					default:
					TXfame[1]='E';
					TXfame[2]=USART_DATA[1];
					TXfame[3]=USART_DATA[2];
					TXfame[4]='*';
					guichu(TXfame);
				}
		}
	}
	DMA_ClearITPendingBit( DMA1_IT_TC5 );
}

void USART1_IRQHandler(void)
{		 
		if(USART_GetITStatus(USART1,USART_IT_IDLE)==SET)
		{
					DMA_Cmd(DMA1_Channel5, DISABLE);
					DMA_SetCurrDataCounter(DMA1_Channel5,5);
					DMA_Cmd(DMA1_Channel5, ENABLE);	     	
		}
	temp=USART1->SR;
	temp=USART1->DR;// xoa co IDLE
}

int main(){
	GPIOinit();
	delayinit();
	UARTinit();
	ADC_CONFIG();
		while(1)
		{
			LM35_TEMP=0;
			for(int i=0;i<100;i++)
			{
			LM35_TEMP+=ADC_data*3*100/4096;
				delayms(3);
			}
			LM32_MEANTEMP=LM35_TEMP/100;
//		GPIOC->ODR ^=(1<<13);
//			delayms(1000);		
//			guichu("chao");
		}
}
