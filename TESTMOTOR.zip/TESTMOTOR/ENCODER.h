#ifndef encode_H
#define encode_H
#include "stm32f10x.h"
void encodeconfig(void);
#endif
